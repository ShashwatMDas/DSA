#include<iostream>
#include <bits/stdc++.h>

using namespace std;

vector<int> prodV(vector<int> &v, int i)
{

    if(i == v.size()-1)
        return v;
    int prod = 1;
    for(int j = i; j < v.size(); j++)
    {
        prod *= v[j];
    }
    v[i] = prod;
    prodV(v, i+1);

    return v;

}

int main()
{

    vector<int> a;
    int n;
    cin >> n;
    for(int i = 0; i < n; i++)
    cin >> a[i];
    return 0;

}
